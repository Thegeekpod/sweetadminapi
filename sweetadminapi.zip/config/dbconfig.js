const dbconfig = {
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'sweetadmin',
  jwtSecret: 'your_jwt_secret'
};

module.exports = dbconfig;
// const dbconfig = {
//   host: 'uueziobj_sweetadmin',
//   user: 'uueziobj_sweetadmin',
//   password: 'admin_sweet',
//   database: 'uueziobj_sweetadmin',
//   jwtSecret: 'your_jwt_secret_dddfn'
// };

// module.exports = dbconfig;
